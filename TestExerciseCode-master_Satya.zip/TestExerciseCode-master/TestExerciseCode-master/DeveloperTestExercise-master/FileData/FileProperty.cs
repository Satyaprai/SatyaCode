﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;

namespace FileData
{
    class FileProperty
    {
        public static void getFileVersion(string fileName)
        {
            IShape _IShape = new FileDetails();
            Console.WriteLine("Version of file is {0}", _IShape.Version(fileName));
        }

        public static void getFileSize(string fileName)
        {
            IShape _IShape = new FileDetails();
            Console.WriteLine("Size of file is {0}", _IShape.Size(fileName));
        }

        public static void errorLogging(string error)
        {
            Console.WriteLine("Error Occured, Error details are {0}", error);
        }

    }
}
