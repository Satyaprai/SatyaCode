﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;
using System.Configuration;

namespace FileData
{
    public static class Program
    {
        private static string sFunctionToPerform = string.Empty;
        private static string sFileName = string.Empty;
        private static string functionToPerformV = string.Empty;
        private static string functionToPerformS = string.Empty;

        public enum function
        {
            functionToPerformV,
            functionToPerformS,
        }

        public static void Main(string[] args)
        {
            try
            {
                functionToPerformV = ConfigurationManager.AppSettings[function.functionToPerformV.ToString()];
                functionToPerformS = ConfigurationManager.AppSettings[function.functionToPerformS.ToString()];               

                Console.WriteLine("Please enter function to Perform");
                sFunctionToPerform = Console.ReadLine();

                Console.WriteLine("Please enter file Name");
                sFileName = Console.ReadLine();

                if (!string.IsNullOrEmpty(functionToPerformV) && !string.IsNullOrEmpty(functionToPerformS))
                {
                    if (functionToPerformV.Contains(sFunctionToPerform))
                    {
                        string[] keyWords = functionToPerformV.Split(',');

                        if (keyWords != null)
                        {
                            foreach (var word in keyWords)
                            {
                                if (word != null)
                                {
                                    if (word.TrimStart() == sFunctionToPerform)
                                    {
                                        FileProperty.getFileVersion(sFileName);
                                    }
                                }
                            }
                        }
                    }
                    else if (functionToPerformS.Contains(sFunctionToPerform))
                    {
                        string[] keyWords = functionToPerformS.Split(',');

                        if (keyWords != null)
                        {
                            foreach (var word in keyWords)
                            {
                                if (word != null)
                                {
                                    if (word.TrimStart() == sFunctionToPerform)
                                    {
                                        FileProperty.getFileSize(sFileName);
                                    }
                                }
                            }
                        }
                    }
                    else
                        Console.WriteLine("Invalid argument, Please try again");
                }
                else
                    Console.WriteLine("Please define the operation to perform");

                Console.WriteLine(Environment.NewLine + "End");
                Console.Read();
            }
            catch (Exception ex)
            {
                FileProperty.errorLogging(ex.Message);
                Console.Read();
            }
        }       
    }
}
